//*******************************************************
//
//               Delphi DataSnap Framework
//
// Copyright(c) 1995-2011 Embarcadero Technologies, Inc.
//
//*******************************************************

#import "DBXCallback.h"





@implementation DBXCallback
-(TJSONValue *) execute:(TJSONValue *) value andJSONTYPE:(int)jsonType{
	return nil;
}
@end
